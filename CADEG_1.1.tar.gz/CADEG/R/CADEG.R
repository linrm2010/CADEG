################################################################################
# CADEG package
# Copyright (C) Runmao Lin, Xinlei Guo, Jian Wu, Jianli Liang, Xiaowu Wang
# Contact (E-mail): linrunmao@caas.cn
# 
# other packages are required to import: VennDiagram, Biobase, limma, gplots
################################################################################

# library(VennDiagram)
# library(Biobase)
# library(limma)
# library(gplots)

################################################################################
# RemoveUnexpGenes
# To remove genes with the maximum expression value less than the cutoff of value.
################################################################################
RemoveUnexpGenes <- function(input_file, cutoff, output_file = "gene_exp.clean.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	if(missing(cutoff)){
		stop("Please provide the cutoff of values.")
	}
	gene_exp <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	remove_row <- c()
	for(i in 1:nrow(gene_exp)){
		if(max(gene_exp[i,]) < cutoff){
			remove_row <- append(remove_row, i)
		}
	}
	if(length(remove_row) != 0){
		gene_exp <- gene_exp[-remove_row,]
	}
	write.table(gene_exp, file = output_file, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
}

################################################################################
# CalPvalueLog
# To calculates p-values, FDR, and fold change values for genes based on their transcriptomic expressions.
################################################################################
CalPvalueLog <- function(input_file, sampleA, sampleB, output_file = "comparison.A-vs-B.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	if(missing(sampleA)){
		stop("Please provide the ID of sample A.")
	}
	if(missing(sampleB)){
		stop("Please provide the ID of sample B.")
	}
	gene_exp <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	sample_names <- colnames(gene_exp)
	SA_column <- 0
	SB_column <- 0
	for(i in 1:length(sample_names)){
		if(sampleA == sample_names[i]){
			SA_column <- i
		}
		if(sampleB == sample_names[i]){
			SB_column <- i
		}
	}
	remove_row <- c()
	for(i in 1:nrow(gene_exp)){
		if(gene_exp[i, SA_column] < 0.5 & gene_exp[i, SB_column] < 0.5){
			remove_row <- append(remove_row, i)
		}
	}
	if(length(remove_row) != 0){
		gene_exp <- gene_exp[-remove_row,]
	}
	gene_num <- nrow(gene_exp)
	sum_sample_A <- sum(gene_exp[, SA_column])
	sum_sample_B <- sum(gene_exp[, SB_column])
	com_Pvalue = c(1:gene_num)
	com_Qvalue = c(1:gene_num)
	com_Log = c(1:gene_num)
	for(i in 1:gene_num){
		expA <- gene_exp[i, SA_column]
		expB <- gene_exp[i, SB_column]
		if(expA >0 || expB > 0){
			com_Pvalue[i] <- chisq.test(matrix(c(expA, sum_sample_A - expA, expB, sum_sample_B - expB), nrow = 2))$p.value
			com_Log[i] <- log2(expB/expA)
		}
		else{
			com_Pvalue[i] <- "NA"
			com_Log[i] <- "NA"
		}
	}
	com_Qvalue <- p.adjust(com_Pvalue, "BH")
	gene_exp$Pvalue <- com_Pvalue
	gene_exp$FDR <- com_Qvalue
	gene_exp$FoldChange <- com_Log
	write.table(gene_exp, file = output_file, quote = FALSE, sep ="\t", col.names = NA, row.names = TRUE)
}

################################################################################
# SelDiffOneCriterion
# To identify differently expressed genes based on file produced by 'CalPvalueLog'.
# the 'type' parameter: 'Pvalue', or 'FDR', or 'FoldChange'
################################################################################
SelDiffOneCriterion <- function(input_file, value, type, output_file = "comparison.A-vs-B.Diff.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	if(missing(value)){
		stop("Please provide the cutoff of value.")
	}
	if(missing(type)){
		stop("Please provide the type of 'Pvalue' or 'FDR' or 'FoldChange'.")
	}
#	print (type)
	gene_exp <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	sample_names <- colnames(gene_exp)
	type_column <- 0
	for(i in 1:length(sample_names)){
		if(type == sample_names[i]){
			type_column <- i
		}
	}
	remove_row <- c()
	for(i in 1:nrow(gene_exp)){
		if(is.na(gene_exp[i, type_column])){
			remove_row <- append(remove_row, i)
		}
		else if((type == "Pvalue" | type == 'FDR') & gene_exp[i, type_column] > value){
			remove_row <- append(remove_row, i)
		}
		else if(type == "FoldChange" & (abs(gene_exp[i, type_column]) < value)){
			remove_row <- append(remove_row, i)
		}
	}
	if(length(remove_row) != 0){
		gene_exp <- gene_exp[-remove_row,]
	}
	write.table(gene_exp, file = output_file, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
}

################################################################################
# SelDiffTwoCriterion
# To identify differently expressed genes based on file produced by 'CalPvalueLog'.
# the 'typeA' parameter: 'Pvalue', or 'FDR'
# the 'typeB, parameter: 'FoldChange'
################################################################################
SelDiffTwoCriterion <- function(input_file, valueA, typeA, valueB, typeB, output_file = "comparison.A-vs-B.Diff.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	if(missing(valueA)){
		stop("Please provide the cutoff of valueA.")
	}
	if(missing(typeA)){
		stop("Please provide the typeA of 'Pvalue' or 'FDR'.")
	}
	if(missing(valueB)){
		stop("Please provide the cutoff of valueB.")
	}
	if(missing(typeB)){
		stop("Please provide the typeB of 'FoldChange'.")
	}
#	print (type)
	gene_exp <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	sample_names <- colnames(gene_exp)
	type_1_column <- 0
	type_2_column <- 0
	for(i in 1:length(sample_names)){
		if(typeA == sample_names[i]){
			type_1_column <- i
		}
		if(typeB == sample_names[i]){
			type_2_column <- i
		}
	}
	remove_row <- c()
	for(i in 1:nrow(gene_exp)){
		if(is.na(gene_exp[i, type_1_column]) | is.na(gene_exp[i, type_2_column])){
			remove_row <- append(remove_row, i)
		}
		else if(gene_exp[i, type_1_column] > valueA | (abs(gene_exp[i, type_2_column]) < valueB)){
			remove_row <- append(remove_row, i)
		}
	}
	if(length(remove_row) != 0){
		gene_exp <- gene_exp[-remove_row,]
	}
	write.table(gene_exp, file = output_file, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
}

################################################################################
# PlusPfamAnnotation
# To add Pfam domain annotations of genes in a special file. 
# The 'Pfam.genedomain' is required and is produced by the perl program of 'PfamAnnotation'.
################################################################################
PlusPfamAnnotation <- function(input_file, Pfam_domain_file, evalue, output_file = "gene.Pfam.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	if(missing(Pfam_domain_file)){
		stop("Please provide the Pfam_domain_file.")
	}
	if(missing(evalue)){
		stop("Please provide the evalue.")
	}
	gene_exp <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	geneID <- rownames(gene_exp)
	sampleID <- colnames(gene_exp)
############################## Pfamdomain format ###############################
# Bra000001	PF03372.22	Exo_endo_phos	2.6e-13	4.3e-13	Endonuclease/Exonuclease/phosphatase family
# ...
################################################################################
	Pfam_infor <- read.table(Pfam_domain_file, header = FALSE, sep = "\t", quote = "")
	remove_row <- c()
	for(i in 1:nrow(Pfam_infor)){
		if(Pfam_infor[i, 5] > evalue){
			remove_row <- append(remove_row, i)
		}
		else if(Pfam_infor[i, 5] <= evalue){
			exist_tag <- 0
			for(j in 1:length(geneID)){
				if(Pfam_infor[i, 1] == geneID[j]){
					exist_tag <- 1
				}
			}
			if(exist_tag == 0){
				remove_row <- append(remove_row, i)
			}
		}
	}
	if(length(remove_row) != 0){
		Pfam_infor <- Pfam_infor[-remove_row,]
	}
	annotation <- c()
	annotation <- append(annotation, as.character(""))
	for(i in 1:length(sampleID)){
		annotation <- append(annotation, sampleID[i])
	}
	annotation <- append(annotation, as.character("PfamAccession"))
	annotation <- append(annotation, as.character("Description"))
	new_matrix <- matrix(annotation, nrow = 1)
	for(i in 1:nrow(gene_exp)){
		Pfam_annotation_tag <- 0
		if(!(length(rownames(Pfam_infor)) == 0))
		{
			for(j in 1:nrow(Pfam_infor)){
				if(Pfam_infor[j, 5] < evalue & Pfam_infor[j, 1] == geneID[i]){
					annotation <- c()
					annotation <- as.character(geneID[i])
					for(k in 1:length(sampleID)){
						annotation <- append(annotation, gene_exp[i, k])
					}
					annotation <- append(annotation, as.character(Pfam_infor[j,2]))
					annotation <- append(annotation, as.character(Pfam_infor[j,6]))
					new_matrix <- rbind(new_matrix, matrix(annotation, nrow = 1))
					Pfam_annotation_tag <- 1
				}
			}
		}
		if(Pfam_annotation_tag == 0){
			annotation <- c()
			annotation <- as.character(geneID[i])
			for(k in 1:length(sampleID)){
				annotation <- append(annotation, gene_exp[i, k])
			}
			annotation <- append(annotation, as.character(" --"))
			annotation <- append(annotation, as.character(" --"))
			new_matrix <- rbind(new_matrix, matrix(annotation, nrow = 1))
		}
	}
	write.table(new_matrix, file = output_file, quote = FALSE, sep = "\t", col.names = F, row.names = F)
}

################################################################################
# DEGPfamAnnotationDis
# To identify functional distribution of DEG genes. 
################################################################################
DEGPfamAnnotationDis <- function(DEG_Pfam_file, exp_gene_file, Pfam_domain_file, evalue, output_file = "DEG.Pfam.Dis.txt"){
	if(missing(DEG_Pfam_file)){
		stop("Please provide the DEG_Pfam_file.")
	}
	if(missing(exp_gene_file)){
		stop("Please provide the exp_gene_file.")
	}
	if(missing(Pfam_domain_file)){
		stop("Please provide the Pfam_domain_file.")
	}
	if(missing(evalue)){
		stop("Please provide the evalue.")
	}
	gene_exp <- read.table(exp_gene_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	geneID <- rownames(gene_exp)
	DEG_exp <- read.table(DEG_Pfam_file, header = TRUE, sep = "\t", quote = "", as.is = TRUE)
	remove_row <- c()
	for(i in 1:nrow(DEG_exp)){
		if(DEG_exp$PfamAccession[i] == " --"){
			remove_row <- append(remove_row, i)
		}
	}
	if(length(remove_row) != 0){
		DEG_exp <- DEG_exp[-remove_row,]
	}
	DEG_ID_table <- table(DEG_exp[,1])
	DEG_ID_num <- length(names(DEG_ID_table))
	Pfam_infor <- read.table(Pfam_domain_file, header = FALSE, sep = "\t", quote = "")
	remove_row <- c()
	for(i in 1:nrow(Pfam_infor)){
		if(Pfam_infor[i, 5] > evalue){
			remove_row <- append(remove_row, i)
		}
	}
	if(length(remove_row) != 0){
		Pfam_infor <- Pfam_infor[-remove_row,]
	}
	all_gene_Pfam_infor <- as.data.frame(table(Pfam_infor[, 2])) ## Var1, Freq
	DEG_gene_Pfam_infor <- as.data.frame(table(DEG_exp$PfamAccession))
	new_matrix <- matrix(c("Accession", "Fnum_m", "Onum_n", "Dnum_q", "DAnum_k"), nrow = 1)
	for(i in 1:length(all_gene_Pfam_infor$Var1)){
		gene_category_infor <- c(as.character(all_gene_Pfam_infor$Var1[i]))
		DEG_exist_tag <- 0
		for(j in 1:length(DEG_gene_Pfam_infor$Var1)){
			if(all_gene_Pfam_infor$Var1[i] == DEG_gene_Pfam_infor$Var1[j] & !(DEG_gene_Pfam_infor$Var1[j] == "--")){
				unexpressed_num <- length(geneID)-all_gene_Pfam_infor$Freq[i]
				gene_category_infor <- append(gene_category_infor, as.numeric(all_gene_Pfam_infor$Freq[i]))
				gene_category_infor <- append(gene_category_infor, as.numeric(unexpressed_num))
				gene_category_infor <- append(gene_category_infor, as.numeric(DEG_gene_Pfam_infor$Freq[j]))
				gene_category_infor <- append(gene_category_infor, as.numeric(DEG_ID_num))
				new_matrix <- rbind(new_matrix, matrix(gene_category_infor, nrow = 1))
				DEG_exist_tag <- 1
				break
			}
		}
		if(DEG_exist_tag == 0){
			gene_category_infor <- append(gene_category_infor, as.numeric(all_gene_Pfam_infor$Freq[i]))
			gene_category_infor <- append(gene_category_infor, as.numeric(length(geneID)-all_gene_Pfam_infor$Freq[i]))
			gene_category_infor <- append(gene_category_infor, as.numeric(0))
			gene_category_infor <- append(gene_category_infor, as.numeric(DEG_ID_num))
			new_matrix <- rbind(new_matrix, matrix(gene_category_infor, nrow = 1))
		}
	}
	new_matrix_file <- "DEG_matrix_file.txt"
	write.table(new_matrix, file = new_matrix_file, quote = FALSE, sep = "\t", col.names = F, row.names = F)
	count <- read.table(new_matrix_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	count_row_ID <- rownames(count)
	for(i in 1:nrow(count)){
		count$Pvalue[i] <- phyper(count[i,3]-1,count[i,1],count[i,2],count[i,4], lower.tail=FALSE)
	}
#	write.table(count, file = "TTT", quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
	Pfam_infor_unique_annotation <- cbind(as.character(Pfam_infor[, 2]), as.character(Pfam_infor[, 6]))
	Pfam_infor_unique_annotation <- unique(Pfam_infor_unique_annotation)
	for(i in 1:length(count_row_ID)){
		for(j in 1:nrow(Pfam_infor_unique_annotation)){
			if(Pfam_infor_unique_annotation[j, 1] == count_row_ID[i]){
				count$Description[i] <- Pfam_infor_unique_annotation[j, 2]
				break
			}
		}
	}
	count_selection <- count
	remove_row_disPvalue <- c()
	for(i in 1:nrow(count_selection)){
		if(count_selection[i, 5] > 0.05){
			remove_row_disPvalue <- append(remove_row_disPvalue, i)
		}
	}
	if(length(remove_row_disPvalue) != 0){
		count_selection <- count_selection[-remove_row_disPvalue,]
	}
	write.table(count, file = output_file, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
	output_file_disPvalue <- paste(c(as.character(output_file), ".Pvalue0.05.txt"), collapse="")
	write.table(count_selection, file = output_file_disPvalue, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
#	file.remove(new_matrix_file)
}

################################################################################
# PlusOtherAnnotation
# To add other functional annotations of genes in a special file. 
# The 'gene_annotaion' file is required.
################################################################################
PlusOtherAnnotation <- function(input_file, gene_annotaion_file, output_file = "gene.annotation.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	if(missing(gene_annotaion_file)){
		stop("Please provide the gene_annotaion_file.")
	}
	gene_exp <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	geneID <- rownames(gene_exp)
############################## Pfamdomain format ###############################
# GeneID	Annotation
# Bra000311	Chitinase class I
# ...
################################################################################
	annotation_infor <- read.table(gene_annotaion_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	annotation_geneID <- rownames(annotation_infor)
	for(i in 1:nrow(gene_exp)){
		annotation_tag <- 0
		for(j in 1:length(annotation_geneID)){
			if(annotation_geneID[j] == geneID[i]){
				gene_exp$Annotation[i] <- as.character(annotation_infor[j,1])
				annotation_tag <- 1
				break
			}
		}
		if(annotation_tag == 0){
			gene_exp$Annotation[i] <- as.character(" --")
		}
	}
	write.table(gene_exp, file = output_file, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
}

################################################################################
# HypergeometricDis
# To produce P-value by the hypergeometric distribution method.
# phyper(q, m, n, k, lower.tail = FLASE)
# q: vector of quantiles representing the number of white balls drawn without 
#    replacement from an urn which contains both black and white balls.
# m: the number of white balls in the urn.
# n: the number of black balls in the urn.
# k: the number of balls drawn from the urn.
# lower.tail: logical; if TRUE (default), probabilities are P[X <= x], otherwise, P[X > x].
################################################################################
HypergeometricDis <- function(input_file, output_file = "gene.annotation.enrich.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
############################## input_file format ###############################
# Accession	Fnum_m	Onum_n	Dnum_q	DAnum_k
# PF00001.20	1	27023	0	907
# ...
################################################################################
	count <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	for(i in 1:nrow(count)){
		count$Pvalue[i] <- phyper(count[i,3]-1,count[i,1],count[i,2],count[i,4], lower.tail=FALSE)
	}
	write.table(count, file = output_file, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
}

################################################################################
# SelGeneAnnotation
# To select annotations by gene IDs.
################################################################################
SelGeneAnnotation <- function(input_file, geneID_file, output_file = "gene.select.txt"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	if(missing(geneID_file)){
		stop("Please provide the geneID_file.")
	}
	select_geneID <- read.table(geneID_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
#	print(select_geneID)
	count <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	count_geneID <- rownames(count)
	remove_row <- c()
	for(i in 1:length(count_geneID)){
		select_geneID_tag <- 0
		for(j in 1:nrow(select_geneID)){
			if(select_geneID[j,1] == count_geneID[i]){
				select_geneID_tag <- 1
				break
			}
		}
		if(select_geneID_tag == 0){
			remove_row <- append(remove_row, i)
		}
	}
	if(length(remove_row) != 0){
		count <- count[-remove_row,]
	}
	write.table(count, file = output_file, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
}

################################################################################
# VennTwoSet
# To draw venn graph.
################################################################################
VennTwoSet <- function(file_sampleA, file_sampleB, sampleA, sampleB, header = TRUE, output_file = "venn.pdf", output_geneID = TRUE){
	if(missing(file_sampleA)){
		stop("Please provide the file_sampleA.")
	}
	if(missing(file_sampleB)){
		stop("Please provide the file_sampleB.")
	}
	if(missing(sampleA)){
		stop("Please provide the sampleA.")
	}
	if(missing(sampleB)){
		stop("Please provide the sampleB.")
	}
	if(missing(header)){
		header = "TRUE"
	}
	else if(!(header == "FLASE")){
		header = "TRUE"
	}
	if(missing(output_geneID)){
		output_geneID = "TRUE"
	}
	else if(!(output_geneID == "FLASE")){
		output_geneID = "TRUE"
	}
############################## file format #####################################
# Gene1
# Gene2
# ...
################################################################################
	if(header == "FLASE"){
		file_sampleA_geneID <- read.table(file_sampleA, header = FALSE, sep = "\t", quote = "")
		file_sampleB_geneID <- read.table(file_sampleB, header = FALSE, sep = "\t", quote = "")
	}
	else{
		file_sampleA_geneID <- read.table(file_sampleA, header = TRUE, sep = "\t", quote = "")
		file_sampleB_geneID <- read.table(file_sampleB, header = TRUE, sep = "\t", quote = "")
	}
	S1geneID <- c()
	S2geneID <- c()
	overlap <- c()
	for(i in 1:nrow(file_sampleA_geneID)){
		S1geneID <- append(S1geneID, as.character(file_sampleA_geneID[i,1]))
		for(j in 1:nrow(file_sampleB_geneID)){
			if(file_sampleA_geneID[i,1] == file_sampleB_geneID[j,1]){
				overlap <- append(overlap, as.character(file_sampleA_geneID[i,1]))
				break
			}
		}
	}
	for(j in 1:nrow(file_sampleB_geneID)){
		S2geneID <- append(S2geneID, as.character(file_sampleB_geneID[j,1]))
	}
#	pdf(output_file)
	draw.pairwise.venn(nrow(file_sampleA_geneID), nrow(file_sampleB_geneID), length(overlap), c(sampleA, sampleB), scaled = FALSE)
#	dev.off()
	S1uniqID <- paste(c(as.character(output_file), ".S1uniqID.txt"), collapse="")
	S2uniqID <- paste(c(as.character(output_file), ".S2uniqID.txt"), collapse="")
	overlapID <- paste(c(as.character(output_file), ".S1.S2.overlapID.txt"), collapse="")
	if(output_geneID == "TRUE"){
# S1uniqID
		remove_list <- c()
		for(i in 1:length(overlap)){
			for(j in 1:length(S1geneID)){
				if(overlap[i] == S1geneID[j]){
					remove_list <- append(remove_list, j)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S1geneID <- S1geneID[-remove_list]
		}
		write.table(S1geneID, file = S1uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S2uniqID
		remove_list <- c()
		for(i in 1:length(overlap)){
			for(j in 1:length(S2geneID)){
				if(overlap[i] == S2geneID[j]){
					remove_list <- append(remove_list, j)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S2geneID <- S2geneID[-remove_list]
		}
		write.table(S2geneID, file = S2uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# overlapID
		write.table(overlap, file = overlapID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
	}
}

################################################################################
# VennThreeSet
# To draw venn graph.
################################################################################
VennThreeSet <- function(file_sampleA, file_sampleB, file_sampleC, sampleA, sampleB, sampleC, header = TRUE, output_file = "venn.pdf", output_geneID = TRUE){
	if(missing(file_sampleA)){
		stop("Please provide the file_sampleA.")
	}
	if(missing(file_sampleB)){
		stop("Please provide the file_sampleB.")
	}
	if(missing(file_sampleC)){
		stop("Please provide the file_sampleC.")
	}
	if(missing(sampleA)){
		stop("Please provide the sampleA.")
	}
	if(missing(sampleB)){
		stop("Please provide the sampleB.")
	}
	if(missing(sampleC)){
		stop("Please provide the sampleC.")
	}
	if(missing(header)){
		header = "TRUE"
	}
	else if(!(header == "FLASE")){
		header = "TRUE"
	}
	if(missing(output_geneID)){
		output_geneID = "TRUE"
	}
	else if(!(output_geneID == "FLASE")){
		output_geneID = "TRUE"
	}
############################## file format #####################################
# Gene1
# Gene2
# ...
################################################################################
	if(header == "FLASE"){
		file_sampleA_geneID <- read.table(file_sampleA, header = FALSE, sep = "\t", quote = "")
		file_sampleB_geneID <- read.table(file_sampleB, header = FALSE, sep = "\t", quote = "")
		file_sampleC_geneID <- read.table(file_sampleC, header = FALSE, sep = "\t", quote = "")
	}
	else{
		file_sampleA_geneID <- read.table(file_sampleA, header = TRUE, sep = "\t", quote = "")
		file_sampleB_geneID <- read.table(file_sampleB, header = TRUE, sep = "\t", quote = "")
		file_sampleC_geneID <- read.table(file_sampleC, header = TRUE, sep = "\t", quote = "")
	}
# checking repeats
	S1geneID <- c()
	S2geneID <- c()
	S3geneID <- c()
	S1S2geneID <- c()
	S1S3geneID <- c()
	S2S3geneID <- c()
	overlap12 <- c()
	overlap13 <- c()
	overlap23 <- c()
	overlap123 <- c()
	for(i in 1:nrow(file_sampleA_geneID)){
		S1geneID <- append(S1geneID, as.character(file_sampleA_geneID[i,1]))
		for(j in 1:nrow(file_sampleB_geneID)){
			if(file_sampleA_geneID[i,1] == file_sampleB_geneID[j,1]){
				overlap12 <- append(overlap12, as.character(file_sampleA_geneID[i,1]))
				S1S2geneID <- append(S1S2geneID, as.character(file_sampleA_geneID[i,1]))
				for(k in 1:nrow(file_sampleC_geneID)){
					if(file_sampleA_geneID[i,1] == file_sampleC_geneID[k,1]){
						overlap123 <- append(overlap123, as.character(file_sampleA_geneID[i,1]))
						break
					}
				}
				break
			}
		}
	}
	for(i in 1:nrow(file_sampleA_geneID)){
		for(k in 1:nrow(file_sampleC_geneID)){
			if(file_sampleA_geneID[i,1] == file_sampleC_geneID[k,1]){
				overlap13 <- append(overlap13, as.character(file_sampleA_geneID[i,1]))
				S1S3geneID <- append(S1S3geneID, as.character(file_sampleA_geneID[i,1]))
				break
			}
		}
	}
	for(j in 1:nrow(file_sampleB_geneID)){
		S2geneID <- append(S2geneID, as.character(file_sampleB_geneID[j,1]))
		for(k in 1:nrow(file_sampleC_geneID)){
			if(file_sampleB_geneID[j,1] == file_sampleC_geneID[k,1]){
				overlap23 <- append(overlap23, as.character(file_sampleB_geneID[j,1]))
				S2S3geneID <- append(S2S3geneID, as.character(file_sampleB_geneID[j,1]))
				break
			}
		}
	}
	for(k in 1:nrow(file_sampleC_geneID)){
		S3geneID <- append(S3geneID, as.character(file_sampleC_geneID[k, 1]))
	}
#	pdf(output_file)
	draw.triple.venn(area1 = nrow(file_sampleA_geneID), area2 = nrow(file_sampleB_geneID), area3 = nrow(file_sampleC_geneID), n12 = length(overlap12), n23 = length(overlap23), n13 = length(overlap13), n123 = length(overlap123), category = c(sampleA, sampleB, sampleC))
#	dev.off()
	S1uniqID <- paste(c(as.character(output_file), ".S1uniqID.txt"), collapse="")
	S2uniqID <- paste(c(as.character(output_file), ".S2uniqID.txt"), collapse="")
	S3uniqID <- paste(c(as.character(output_file), ".S3uniqID.txt"), collapse="")
	S1S2uniqID <- paste(c(as.character(output_file), ".S1S2uniqID.txt"), collapse="")
	S1S3uniqID <- paste(c(as.character(output_file), ".S1S3uniqID.txt"), collapse="")
	S2S3uniqID <- paste(c(as.character(output_file), ".S2S3uniqID.txt"), collapse="")
	overlapID <- paste(c(as.character(output_file), ".S1.S2.S3.overlapID.txt"), collapse="")
	if(output_geneID == "TRUE"){
# S1uniqID
		remove_list <- c()
		for(i in 1:length(S1geneID)){
			for(j in 1:length(overlap12)){
				if(overlap12[j] == S1geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S1geneID <- S1geneID[-remove_list]
		}
		remove_list <- c()
		for(i in 1:length(S1geneID)){
			for(j in 1:length(overlap13)){
				if(overlap13[j] == S1geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S1geneID <- S1geneID[-remove_list]
		}
		write.table(S1geneID, file = S1uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S2uniqID
		remove_list <- c()
		for(i in 1:length(S2geneID)){
			for(j in 1:length(overlap12)){
				if(overlap12[j] == S2geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S2geneID <- S2geneID[-remove_list]
		}
		remove_list <- c()
		for(i in 1:length(S2geneID)){
			for(j in 1:length(overlap23)){
				if(overlap23[j] == S2geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S2geneID <- S2geneID[-remove_list]
		}
		write.table(S2geneID, file = S2uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S3uniqID
		remove_list <- c()
		for(i in 1:length(S3geneID)){
			for(j in 1:length(overlap13)){
				if(overlap13[j] == S3geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S3geneID <- S3geneID[-remove_list]
		}
		remove_list <- c()
		for(i in 1:length(S3geneID)){
			for(j in 1:length(overlap23)){
				if(overlap23[j] == S3geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S3geneID <- S3geneID[-remove_list]
		}
		write.table(S3geneID, file = S3uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S3uniqID
		remove_list <- c()
		for(i in 1:length(S1S3geneID)){
			for(j in 1:length(overlap123)){
				if(overlap123[j] == S1S3geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S1S3geneID <- S1S3geneID[-remove_list]
		}
		write.table(S1S3geneID, file = S1S3uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S2uniqID
		remove_list <- c()
		for(i in 1:length(S1S2geneID)){
			for(j in 1:length(overlap123)){
				if(overlap123[j] == S1S2geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S1S2geneID <- S1S2geneID[-remove_list]
		}
		write.table(S1S2geneID, file = S1S2uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S2S3uniqID
		remove_list <- c()
		for(i in 1:length(S2S3geneID)){
			for(j in 1:length(overlap123)){
				if(overlap123[j] == S2S3geneID[i]){
					remove_list <- append(remove_list, i)
					break
				}
			}
		}
		if(length(remove_list) != 0){
			S2S3geneID <- S2S3geneID[-remove_list]
		}
		write.table(S2S3geneID, file = S2S3uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# overlapID
		write.table(overlap123, file = overlapID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
	}
}

################################################################################
# VennFourSet
# To draw venn graph.
################################################################################
VennFourSet <- function(file_sampleA, file_sampleB, file_sampleC, file_sampleD, sampleA, sampleB, sampleC, sampleD, header = TRUE, output_file = "venn.pdf", output_geneID = TRUE){
	if(missing(file_sampleA)){
		stop("Please provide the file_sampleA.")
	}
	if(missing(file_sampleB)){
		stop("Please provide the file_sampleB.")
	}
	if(missing(file_sampleC)){
		stop("Please provide the file_sampleC.")
	}
	if(missing(file_sampleD)){
		stop("Please provide the file_sampleC.")
	}
	if(missing(sampleA)){
		stop("Please provide the sampleA.")
	}
	if(missing(sampleB)){
		stop("Please provide the sampleB.")
	}
	if(missing(sampleC)){
		stop("Please provide the sampleC.")
	}
	if(missing(sampleD)){
		stop("Please provide the sampleD.")
	}
	if(missing(header)){
		header = "TRUE"
	}
	else if(!(header == "FLASE")){
		header = "TRUE"
	}
############################## file format #####################################
# Gene1
# Gene2
# ...
################################################################################
	if(header == "FLASE"){
		file_sampleA_geneID <- read.table(file_sampleA, header = FALSE, sep = "\t", quote = "")
		file_sampleB_geneID <- read.table(file_sampleB, header = FALSE, sep = "\t", quote = "")
		file_sampleC_geneID <- read.table(file_sampleC, header = FALSE, sep = "\t", quote = "")
		file_sampleD_geneID <- read.table(file_sampleD, header = FALSE, sep = "\t", quote = "")
	}
	else{
		file_sampleA_geneID <- read.table(file_sampleA, header = TRUE, sep = "\t", quote = "")
		file_sampleB_geneID <- read.table(file_sampleB, header = TRUE, sep = "\t", quote = "")
		file_sampleC_geneID <- read.table(file_sampleC, header = TRUE, sep = "\t", quote = "")
		file_sampleD_geneID <- read.table(file_sampleD, header = TRUE, sep = "\t", quote = "")
	}
# checking repeats
	S1geneID <- c()
	S2geneID <- c()
	S3geneID <- c()
	S4geneID <- c()
	S1S2geneID <- c()
	S1S3geneID <- c()
	S1S4geneID <- c()
	S2S3geneID <- c()
	S2S4geneID <- c()
	S3S4geneID <- c()
	S1S2S3geneID <- c()
	S1S2S4geneID <- c()
	S1S3S4geneID <- c()
	S2S3S4geneID <- c()
	S1S2S3S4geneID <- c()
	overlap12 <- c()
	overlap123 <- c()
	overlap124 <- c()
	overlap1234 <- c()
	overlap13 <- c()
	overlap134 <- c()
	overlap14 <- c()
	overlap23 <- c()
	overlap234 <- c()
	overlap24 <- c()
	overlap34 <- c()
	for(i in 1:nrow(file_sampleA_geneID)){
		S1geneID <- append(S1geneID, as.character(file_sampleA_geneID[i,1]))
		for(j in 1:nrow(file_sampleB_geneID)){
			if(file_sampleA_geneID[i,1] == file_sampleB_geneID[j,1]){
				overlap12 <- append(overlap12, as.character(file_sampleA_geneID[i,1]))
				S1S2geneID <- append(S1S2geneID, as.character(file_sampleA_geneID[i,1]))
				for(k in 1:nrow(file_sampleC_geneID)){
					if(file_sampleA_geneID[i,1] == file_sampleC_geneID[k,1]){
						overlap123 <- append(overlap123, as.character(file_sampleA_geneID[i,1]))
						S1S2S3geneID <- append(S1S2S3geneID, as.character(file_sampleA_geneID[i,1]))
						for(m in 1:nrow(file_sampleD_geneID)){
							if(file_sampleA_geneID[i,1] == file_sampleD_geneID[m,1]){
								overlap1234 <- append(overlap1234, as.character(file_sampleA_geneID[i,1]))
								S1S2S3S4geneID <- append(S1S2S3S4geneID, as.character(file_sampleA_geneID[i,1]))
								break
							}
						}
						break
					}
				}
				break
			}
		}
	}
	for(i in 1:nrow(file_sampleA_geneID)){
		for(j in 1:nrow(file_sampleB_geneID)){
			if(file_sampleA_geneID[i,1] == file_sampleB_geneID[j,1]){
				for(m in 1:nrow(file_sampleD_geneID)){
					if(file_sampleA_geneID[i,1] == file_sampleD_geneID[m,1]){
						overlap124 <- append(overlap124, as.character(file_sampleA_geneID[i,1]))
						S1S2S4geneID <- append(S1S2S4geneID, as.character(file_sampleA_geneID[i,1]))
						break
					}
				}
				break
			}
		}
	}
	for(i in 1:nrow(file_sampleA_geneID)){
		for(k in 1:nrow(file_sampleC_geneID)){
			if(file_sampleA_geneID[i,1] == file_sampleC_geneID[k,1]){
				overlap13 <- append(overlap13, as.character(file_sampleA_geneID[i,1]))
				S1S3geneID <- append(S1S3geneID, as.character(file_sampleA_geneID[i,1]))
				for(m in 1:nrow(file_sampleD_geneID)){
					if(file_sampleA_geneID[i,1] == file_sampleD_geneID[m,1]){
						overlap134 <- append(overlap134, as.character(file_sampleA_geneID[i,1]))
						S1S3S4geneID <- append(S1S3S4geneID, as.character(file_sampleA_geneID[i,1]))
						break
					}
				}
				break
			}
		}
	}
	for(i in 1:nrow(file_sampleA_geneID)){
		for(m in 1:nrow(file_sampleD_geneID)){
			if(file_sampleA_geneID[i,1] == file_sampleD_geneID[m,1]){
				overlap14 <- append(overlap14, as.character(file_sampleA_geneID[i,1]))
				S1S4geneID <- append(S1S4geneID, as.character(file_sampleA_geneID[i,1]))
				break
			}
		}
	}
	for(j in 1:nrow(file_sampleB_geneID)){
		S2geneID <- append(S2geneID, as.character(file_sampleB_geneID[j,1]))
		for(k in 1:nrow(file_sampleC_geneID)){
			if(file_sampleB_geneID[j,1] == file_sampleC_geneID[k,1]){
				overlap23 <- append(overlap23, as.character(file_sampleB_geneID[j,1]))
				S2S3geneID <- append(S2S3geneID, as.character(file_sampleB_geneID[j,1]))
				for(m in 1:nrow(file_sampleD_geneID)){
					if(file_sampleB_geneID[j,1] == file_sampleD_geneID[m,1]){
						overlap234 <- append(overlap234, as.character(file_sampleB_geneID[j,1]))
						S2S3S4geneID <- append(S2S3S4geneID, as.character(file_sampleB_geneID[j,1]))
						break
					}
				}
				break
			}
		}
	}
	for(j in 1:nrow(file_sampleB_geneID)){
		for(m in 1:nrow(file_sampleD_geneID)){
			if(file_sampleB_geneID[j,1] == file_sampleD_geneID[m,1]){
				overlap24 <- append(overlap24, as.character(file_sampleB_geneID[j,1]))
				S2S4geneID <- append(S2S4geneID, as.character(file_sampleB_geneID[j,1]))
				break
			}
		}
	}
	for(k in 1:nrow(file_sampleC_geneID)){
		S3geneID <- append(S3geneID, as.character(file_sampleC_geneID[k,1]))
		for(m in 1:nrow(file_sampleD_geneID)){
			if(file_sampleC_geneID[k,1] == file_sampleD_geneID[m,1]){
				overlap34 <- append(overlap34, as.character(file_sampleC_geneID[k,1]))
				S3S4geneID <- append(S3S4geneID, as.character(file_sampleC_geneID[k,1]))
				break
			}
		}
	}
	for(m in 1:nrow(file_sampleD_geneID)){
		S4geneID <- append(S4geneID, as.character(file_sampleD_geneID[m,1]))
	}
#	pdf(output_file)
	draw.quad.venn(area1 = nrow(file_sampleA_geneID), area2 = nrow(file_sampleB_geneID), area3 = nrow(file_sampleC_geneID), area4 = nrow(file_sampleD_geneID), n12 = length(overlap12), n13 = length(overlap13), n14 = length(overlap14), n23 = length(overlap23), n24 = length(overlap24), n34 = length(overlap34), n123 = length(overlap123), n124 = length(overlap124), n134 = length(overlap134), n234 = length(overlap234), n1234 = length(overlap1234), category = c(sampleA, sampleB, sampleC, sampleD))
#	dev.off()
	S1uniqID <- paste(c(as.character(output_file), ".S1uniqID.txt"), collapse="")
	S2uniqID <- paste(c(as.character(output_file), ".S2uniqID.txt"), collapse="")
	S3uniqID <- paste(c(as.character(output_file), ".S3uniqID.txt"), collapse="")
	S4uniqID <- paste(c(as.character(output_file), ".S4uniqID.txt"), collapse="")
	S1S2uniqID <- paste(c(as.character(output_file), ".S1S2uniqID.txt"), collapse="")
	S1S3uniqID <- paste(c(as.character(output_file), ".S1S3uniqID.txt"), collapse="")
	S1S4uniqID <- paste(c(as.character(output_file), ".S1S4uniqID.txt"), collapse="")
	S2S3uniqID <- paste(c(as.character(output_file), ".S2S3uniqID.txt"), collapse="")
	S2S4uniqID <- paste(c(as.character(output_file), ".S2S4uniqID.txt"), collapse="")
	S3S4uniqID <- paste(c(as.character(output_file), ".S3S4uniqID.txt"), collapse="")
	S1S2S3uniqID <- paste(c(as.character(output_file), ".S1S2S3uniqID.txt"), collapse="")
	S1S2S4uniqID <- paste(c(as.character(output_file), ".S1S2S4uniqID.txt"), collapse="")
	S1S3S4uniqID <- paste(c(as.character(output_file), ".S1S3S4uniqID.txt"), collapse="")
	S2S3S4uniqID <- paste(c(as.character(output_file), ".S2S3S4uniqID.txt"), collapse="")
	overlapID <- paste(c(as.character(output_file), ".S1.S2.S3.S4.overlapID.txt"), collapse="")
	if(output_geneID == "TRUE"){
# S1uniqID
		remove_list_S1uniqID <- c()
		for(i in 1:length(S1geneID)){
			for(j in 1:length(overlap12)){
				if(overlap12[j] == S1geneID[i]){
					remove_list_S1uniqID <- append(remove_list_S1uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1uniqID) != 0){
			S1geneID <- S1geneID[-remove_list_S1uniqID]
		}
		remove_list_S1uniqID <- c()
		for(i in 1:length(S1geneID)){
			for(j in 1:length(overlap13)){
				if(overlap13[j] == S1geneID[i]){
					remove_list_S1uniqID <- append(remove_list_S1uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1uniqID) != 0){
			S1geneID <- S1geneID[-remove_list_S1uniqID]
		}
		remove_list_S1uniqID <- c()
		for(i in 1:length(S1geneID)){
			for(j in 1:length(overlap14)){
				if(overlap14[j] == S1geneID[i]){
					remove_list_S1uniqID <- append(remove_list_S1uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1uniqID) != 0){
			S1geneID <- S1geneID[-remove_list_S1uniqID]
		}
		write.table(S1geneID, file = S1uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S2uniqID
		remove_list_S2uniqID <- c()
		for(i in 1:length(S2geneID)){
			for(j in 1:length(overlap12)){
				if(overlap12[j] == S2geneID[i]){
					remove_list_S2uniqID <- append(remove_list_S2uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2uniqID) != 0){
			S2geneID <- S2geneID[-remove_list_S2uniqID]
		}
		remove_list_S2uniqID <- c()
		for(i in 1:length(S2geneID)){
			for(j in 1:length(overlap23)){
				if(overlap23[j] == S2geneID[i]){
					remove_list_S2uniqID <- append(remove_list_S2uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2uniqID) != 0){
			S2geneID <- S2geneID[-remove_list_S2uniqID]
		}
		remove_list_S2uniqID <- c()
		for(i in 1:length(S2geneID)){
			for(j in 1:length(overlap24)){
				if(overlap24[j] == S2geneID[i]){
					remove_list_S2uniqID <- append(remove_list_S2uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2uniqID) != 0){
			S2geneID <- S2geneID[-remove_list_S2uniqID]
		}
		write.table(S2geneID, file = S2uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S3uniqID
		remove_list_S3uniqID <- c()
		for(i in 1:length(S3geneID)){
			for(j in 1:length(overlap13)){
				if(overlap13[j] == S3geneID[i]){
					remove_list_S3uniqID <- append(remove_list_S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S3uniqID) != 0){
			S3geneID <- S3geneID[-remove_list_S3uniqID]
		}
		remove_list_S3uniqID <- c()
		for(i in 1:length(S3geneID)){
			for(j in 1:length(overlap23)){
				if(overlap23[j] == S3geneID[i]){
					remove_list_S3uniqID <- append(remove_list_S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S3uniqID) != 0){
			S3geneID <- S3geneID[-remove_list_S3uniqID]
		}
		remove_list_S3uniqID <- c()
		for(i in 1:length(S3geneID)){
			for(j in 1:length(overlap34)){
				if(overlap34[j] == S3geneID[i]){
					remove_list_S3uniqID <- append(remove_list_S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S3uniqID) != 0){
			S3geneID <- S3geneID[-remove_list_S3uniqID]
		}
		write.table(S3geneID, file = S3uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S4uniqID
		remove_list_S4uniqID <- c()
		for(i in 1:length(S4geneID)){
			for(j in 1:length(overlap14)){
				if(overlap14[j] == S4geneID[i]){
					remove_list_S4uniqID <- append(remove_list_S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S4uniqID) != 0){
			S4geneID <- S4geneID[-remove_list_S4uniqID]
		}
		remove_list_S4uniqID <- c()
		for(i in 1:length(S4geneID)){
			for(j in 1:length(overlap24)){
				if(overlap24[j] == S4geneID[i]){
					remove_list_S4uniqID <- append(remove_list_S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S4uniqID) != 0){
			S4geneID <- S4geneID[-remove_list_S4uniqID]
		}
		remove_list_S4uniqID <- c()
		for(i in 1:length(S4geneID)){
			for(j in 1:length(overlap34)){
				if(overlap34[j] == S4geneID[i]){
					remove_list_S4uniqID <- append(remove_list_S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S4uniqID) != 0){
			S4geneID <- S4geneID[-remove_list_S4uniqID]
		}
		write.table(S4geneID, file = S4uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S2uniqID
		remove_list_S1S2uniqID <- c()
		for(i in 1:length(S1S2geneID)){
			for(j in 1:length(overlap123)){
				if(overlap123[j] == S1S2geneID[i]){
					remove_list_S1S2uniqID <- append(remove_list_S1S2uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S2uniqID) != 0){
			S1S2geneID <- S1S2geneID[-remove_list_S1S2uniqID]
		}
		remove_list_S1S2uniqID <- c()
		for(i in 1:length(S1S2geneID)){
			for(j in 1:length(overlap124)){
				if(overlap124[j] == S1S2geneID[i]){
					remove_list_S1S2uniqID <- append(remove_list_S1S2uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S2uniqID) != 0){
			S1S2geneID <- S1S2geneID[-remove_list_S1S2uniqID]
		}
		write.table(S1S2geneID, file = S1S2uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S3uniqID
		remove_list_S1S3uniqID <- c()
		for(i in 1:length(S1S3geneID)){
			for(j in 1:length(overlap123)){
				if(overlap123[j] == S1S3geneID[i]){
					remove_list_S1S3uniqID <- append(remove_list_S1S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S3uniqID) != 0){
			S1S3geneID <- S1S3geneID[-remove_list_S1S3uniqID]
		}
		remove_list_S1S3uniqID <- c()
		for(i in 1:length(S1S3geneID)){
			for(j in 1:length(overlap134)){
				if(overlap134[j] == S1S3geneID[i]){
					remove_list_S1S3uniqID <- append(remove_list_S1S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S3uniqID) != 0){
			S1S3geneID <- S1S3geneID[-remove_list_S1S3uniqID]
		}
		write.table(S1S3geneID, file = S1S3uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S4uniqID
		remove_list_S1S4uniqID <- c()
		for(i in 1:length(S1S4geneID)){
			for(j in 1:length(overlap124)){
				if(overlap124[j] == S1S4geneID[i]){
					remove_list_S1S4uniqID <- append(remove_list_S1S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S4uniqID) != 0){
			S1S4geneID <- S1S4geneID[-remove_list_S1S4uniqID]
		}
		remove_list_S1S4uniqID <- c()
		for(i in 1:length(S1S4geneID)){
			for(j in 1:length(overlap134)){
				if(overlap134[j] == S1S4geneID[i]){
					remove_list_S1S4uniqID <- append(remove_list_S1S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S4uniqID) != 0){
			S1S4geneID <- S1S4geneID[-remove_list_S1S4uniqID]
		}
		write.table(S1S4geneID, file = S1S4uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S2S3uniqID
		remove_list_S2S3uniqID <- c()
		for(i in 1:length(S2S3geneID)){
			for(j in 1:length(overlap123)){
				if(overlap123[j] == S2S3geneID[i]){
					remove_list_S2S3uniqID <- append(remove_list_S2S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2S3uniqID) != 0){
			S2S3geneID <- S2S3geneID[-remove_list_S2S3uniqID]
		}
		remove_list_S2S3uniqID <- c()
		for(i in 1:length(S2S3geneID)){
			for(j in 1:length(overlap234)){
				if(overlap234[j] == S2S3geneID[i]){
					remove_list_S2S3uniqID <- append(remove_list_S2S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2S3uniqID) != 0){
			S2S3geneID <- S2S3geneID[-remove_list_S2S3uniqID]
		}
		write.table(S2S3geneID, file = S2S3uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S2S4uniqID
		remove_list_S2S4uniqID <- c()
		for(i in 1:length(S2S4geneID)){
			for(j in 1:length(overlap124)){
				if(overlap124[j] == S2S4geneID[i]){
					remove_list_S2S4uniqID <- append(remove_list_S2S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2S4uniqID) != 0){
			S2S4geneID <- S2S4geneID[-remove_list_S2S4uniqID]
		}
		remove_list_S2S4uniqID <- c()
		for(i in 1:length(S2S4geneID)){
			for(j in 1:length(overlap234)){
				if(overlap234[j] == S2S4geneID[i]){
					remove_list_S2S4uniqID <- append(remove_list_S2S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2S4uniqID) != 0){
			S2S4geneID <- S2S4geneID[-remove_list_S2S4uniqID]
		}
		write.table(S2S4geneID, file = S2S4uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S3S4uniqID
		remove_list_S3S4uniqID <- c()
		for(i in 1:length(S3S4geneID)){
			for(j in 1:length(overlap134)){
				if(overlap134[j] == S3S4geneID[i]){
					remove_list_S3S4uniqID <- append(remove_list_S3S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S3S4uniqID) != 0){
			S3S4geneID <- S3S4geneID[-remove_list_S3S4uniqID]
		}
		remove_list_S3S4uniqID <- c()
		for(i in 1:length(S3S4geneID)){
			for(j in 1:length(overlap234)){
				if(overlap234[j] == S3S4geneID[i]){
					remove_list_S3S4uniqID <- append(remove_list_S3S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S3S4uniqID) != 0){
			S3S4geneID <- S3S4geneID[-remove_list_S3S4uniqID]
		}
		write.table(S3S4geneID, file = S3S4uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S2S3uniqID
		remove_list_S1S2S3uniqID <- c()
		for(i in 1:length(S1S2S3geneID)){
			for(j in 1:length(overlap1234)){
				if(overlap1234[j] == S1S2S3geneID[i]){
					remove_list_S1S2S3uniqID <- append(remove_list_S1S2S3uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S2S3uniqID) != 0){
			S1S2S3geneID <- S1S2S3geneID[-remove_list_S1S2S3uniqID]
		}
		write.table(S1S2S3geneID, file = S1S2S3uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S2S4uniqID
		remove_list_S1S2S4uniqID <- c()
		for(i in 1:length(S1S2S4geneID)){
			for(j in 1:length(overlap1234)){
				if(overlap1234[j] == S1S2S4geneID[i]){
					remove_list_S1S2S4uniqID <- append(remove_list_S1S2S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S2S4uniqID) != 0){
			S1S2S4geneID <- S1S2S4geneID[-remove_list_S1S2S4uniqID]
		}
		write.table(S1S2S4geneID, file = S1S2S4uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S1S3S4uniqID
		remove_list_S1S3S4uniqID <- c()
		for(i in 1:length(S1S3S4geneID)){
			for(j in 1:length(overlap1234)){
				if(overlap1234[j] == S1S3S4geneID[i]){
					remove_list_S1S3S4uniqID <- append(remove_list_S1S3S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S1S3S4uniqID) != 0){
			S1S3S4geneID <- S1S3S4geneID[-remove_list_S1S3S4uniqID]
		}
		write.table(S1S3S4geneID, file = S1S3S4uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# S2S3S4uniqID
		remove_list_S2S3S4uniqID <- c()
		for(i in 1:length(S2S3S4geneID)){
			for(j in 1:length(overlap1234)){
				if(overlap1234[j] == S2S3S4geneID[i]){
					remove_list_S2S3S4uniqID <- append(remove_list_S2S3S4uniqID, i)
					break
				}
			}
		}
		if(length(remove_list_S2S3S4uniqID) != 0){
			S2S3S4geneID <- S2S3S4geneID[-remove_list_S2S3S4uniqID]
		}
		write.table(S2S3S4geneID, file = S2S3S4uniqID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
# overlapID
		write.table(overlap1234, file = overlapID, quote = FALSE, sep = "\t", col.names = NA, row.names = TRUE)
	}
}

################################################################################
# DrawHeatmap
# To draw heatmap graph.
################################################################################
DrawHeatmap <- function(input_file, to_cluster_sample = TRUE, to_cluster_gene = TRUE, output_file = "heatmap.pdf"){
	if(missing(input_file)){
		stop("Please provide the input_file.")
	}
	width <- 10
	height <- 10
	gene_exp <- read.table(input_file, header = TRUE, sep = "\t", quote = "", row.names = 1, as.is = TRUE)
	genenumber <- length(rownames(gene_exp))
	samplenumber <- length(colnames(gene_exp))
	height <- genenumber*0.2+10
	width <- samplenumber*1+10
	gene_exp_matrix <- as.matrix(gene_exp)
	gene_exp_matrix_infor <- new("ExpressionSet", exprs = gene_exp_matrix)
	spmat <- exprs(gene_exp_matrix_infor)
	gene_exp_matrix_datascale <- t(scale(t(spmat)))
	hr <- hclust(as.dist(1-cor(t(gene_exp_matrix_datascale), method = "pearson")), method="average")
# cexRow, gene ID sizes; cexCol, sample ID sizes; 
	pdf(output_file, height = height, width = width)
	heatmap(spmat,col=bluered(75),margins=c(2,10),cexRow=1,cexCol=5,Rowv=as.dendrogram(hr))
	dev.off()
}
